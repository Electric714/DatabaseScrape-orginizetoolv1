from pathlib import Path


def replace_once(path: str, old: str, new: str, label: str) -> None:
    file_path = Path(path)
    text = file_path.read_text(encoding="utf-8")
    if old not in text:
        raise SystemExit(f"{label}: expected source block was not found in {path}")
    file_path.write_text(text.replace(old, new, 1), encoding="utf-8")


def patch_crawler() -> None:
    path = Path("app/crawler.py")
    text = path.read_text(encoding="utf-8")
    challenge = 'CHALLENGE = re.compile(r"captcha|verify (?:that )?you are human|checking your browser|access denied|cf-chl-|challenge-platform", re.I)\n'
    helper = challenge + '''\n\ndef _has_access_challenge(text: str) -> bool:\n    """Detect block/challenge documents without scanning arbitrary user content.\n\n    Human-readable challenge terms are limited to the beginning of a document.\n    BBB complaint pages can contain customer-written phrases such as \"captcha\"\n    or \"access denied\" deep in normal content; those must not turn evidence into\n    a false blocked outcome.\n    """\n    return bool(CHALLENGE.search((text or "")[:32768]))\n'''
    if "def _has_access_challenge(" not in text:
        if challenge not in text:
            raise SystemExit("crawler challenge marker not found")
        text = text.replace(challenge, helper, 1)
    occurrences = text.count("CHALLENGE.search(result.text)")
    if occurrences:
        text = text.replace("CHALLENGE.search(result.text)", "_has_access_challenge(result.text)")
    elif "_has_access_challenge(result.text)" not in text:
        raise SystemExit("crawler challenge checks not found")

    old = '''            await db.increment_job(self.job_id, errors=1)\n            await db.upsert_page(self.source_id, url, last_error=safe_error[:1000])\n            if getattr(self.adapter, "fail_fast_access_errors", False) and (\n'''
    new = '''            await db.increment_job(self.job_id, errors=1)\n            await db.upsert_page(self.source_id, url, last_error=safe_error[:1000])\n            record_page_error = getattr(self.adapter, "record_page_error", None)\n            if record_page_error:\n                try:\n                    record_page_error(url, safe_error)\n                except Exception as adapter_exc:\n                    activity.emit(\n                        "WARNING", "Source adapter could not record page failure provenance",\n                        source_id=self.source_id, job_id=self.job_id, url=url,\n                        error=activity.redact(str(adapter_exc)),\n                    )\n            if getattr(self.adapter, "fail_fast_access_errors", False) and (\n'''
    if old not in text and "record_page_error = getattr(self.adapter" not in text:
        raise SystemExit("crawler page error hook marker not found")
    if old in text:
        text = text.replace(old, new, 1)
    path.write_text(text, encoding="utf-8")


def patch_main() -> None:
    replace_once(
        "app/main.py",
        '''    for name, url in [\n        ("Violation Tracker", VT_URL),\n        ("Minnesota OSP debarment", MN_URL),\n        ("Illinois public works debarment", IL_URL),\n        ("Wisconsin DOT debarment", WI_URL),\n    ]:\n        if not any(s["start_url"] == url for s in sources):\n            await db.create_source(SourceCreate(name=name, start_url=url, concurrency=1, delay_ms=1500, max_depth=8, max_pages=50, render_mode="http", respect_robots=True).model_dump(mode="json"))\n''',
        '''    for name, url, max_pages in [\n        ("Violation Tracker", VT_URL, 5000),\n        ("Minnesota OSP debarment", MN_URL, 50),\n        ("Illinois public works debarment", IL_URL, 50),\n        ("Wisconsin DOT debarment", WI_URL, 50),\n    ]:\n        if not any(s["start_url"] == url for s in sources):\n            await db.create_source(SourceCreate(name=name, start_url=url, concurrency=1, delay_ms=1500, max_depth=8, max_pages=max_pages, render_mode="http", respect_robots=True).model_dump(mode="json"))\n''',
        "Violation Tracker page budget",
    )


def patch_catalog() -> None:
    replace_once(
        "app/source_catalog.py",
        '''    {"key": "bbb", "name": "Better Business Bureau", "method": "Published profile sitemaps + local profile navigation", "status": "Sitemap discovery verified; local profile access needs validation",\n     "fields": ["better_business_bureau_complaints"], "hosts": ["bbb.org", "www.bbb.org"],\n     "note": "BBB's published business-profile sitemap index is retrieved without a challenge and /search is never used. POC sitemap ranges cover FL, IL, MN, MO, OH, and WI. Cloud raw HTTP and cloud Chromium both received a 403 challenge on profile documents, so discovered profiles use narrowly scoped local Chromium navigation and remain unknown on any challenge/error. Exact profile identity/location is required before /complaints can propose a value."},\n''',
        '''    {"key": "bbb", "name": "Better Business Bureau", "method": "Published profile sitemaps + local profile navigation", "status": "Fail-closed sitemap/profile collector",\n     "fields": ["better_business_bureau_complaints"], "hosts": ["bbb.org", "www.bbb.org"],\n     "note": "BBB's published business-profile sitemap index is used for discovery; /search is not required. POC sitemap ranges cover FL, IL, MN, MO, OH, and WI. Each contractor is isolated so one blocked profile does not invalidate unrelated verified evidence. Exact company and location identity is required, and N is allowed only when the exact verified profile's complaint page is successfully reached and explicitly reports zero in BBB's rolling three-year period. Blocked, malformed, partial, missing-profile, or ambiguous outcomes remain UNKNOWN."},\n''',
        "BBB source catalog",
    )
    replace_once(
        "app/source_catalog.py",
        '''    {"key": "vt", "name": "Violation Tracker", "method": "Targeted HTML", "status": "Blocked",\n     "fields": ["environmental_violations", "prevailing_wage_violations", "misc_violations"], "hosts": ["violationtracker.goodjobsfirst.org"],\n     "note": "Live HTTP 403. Parser provisional; bulk downloads require subscription. General wage-and-hour findings do not prove prevailing-wage violations."},\n''',
        '''    {"key": "vt", "name": "Violation Tracker", "method": "Targeted public HTML", "status": "Fail-closed parser; live access environment-dependent",\n     "fields": ["environmental_violations", "prevailing_wage_violations", "misc_violations"], "hosts": ["violationtracker.goodjobsfirst.org"],\n     "note": "Uses only public search/detail HTML and never subscriber-only downloads. HTTP/access failures, incomplete pagination, and unrecognized layouts remain UNKNOWN. A parent-company result alone never proves a subsidiary/master-contractor match. Generic wage-and-hour findings are retained as evidence but do not map to prevailing-wage violations unless the public record explicitly identifies prevailing-wage, Davis-Bacon, or equivalent public-works wage coverage."},\n''',
        "Violation Tracker source catalog",
    )


patch_crawler()
patch_main()
patch_catalog()
